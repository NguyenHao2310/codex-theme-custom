PIXEL STUDIO V2.0.2 CHO CODEX WINDOWS

Bản sửa 2.0.2: bỏ dải nền đen bao quanh phía dưới ô nhập và hai gradient tối ở mép trên/dưới vùng chat khi bật theme. Giữ nền của chính ô nhập, mặt nạ cuộn chữ và tự khôi phục giao diện gốc khi tắt theme.

Cách dùng
1. Thoát hoàn toàn Codex/ChatGPT bằng Ctrl+Q.
2. Chạy Start-Pixel.cmd. Không cần quyền Administrator.
3. Bấm biểu tượng bốn ô vuông ở hàng nút góc trên bên phải, cạnh các nút trong ảnh bạn đã chỉ.
4. Cảnh Pixel: chọn một trong 9 cảnh có ảnh xem trước.
5. Video: bấm ô thêm video hoặc thả video từ máy vào; chọn MP4/WebM được trình duyệt hỗ trợ, tối đa 200 MB. Video tự lặp và không phát tiếng.
6. Tinh chỉnh: màu phủ, độ sáng, độ rực, độ mờ, độ đục khung chat, tốc độ và kích thước pixel.

Nút Tắt nền chỉ tắt hình nền, vẫn giữ nút trên thanh công cụ để bật lại. Đóng bảng bằng nút X, Escape hoặc bấm ra ngoài.
Lựa chọn và thông số tự lưu trên máy. Video lưu trong IndexedDB của ứng dụng; không được tải lên dịch vụ ngoài. Xóa khỏi thư viện không xóa tệp gốc.
Apply-Pixel.cmd áp dụng lại giao diện nếu Codex đang mở với CDP cục bộ 19327.

Giới hạn
Đây là bản tùy biến bên thứ ba qua runtime, không sửa app.asar hoặc gói ứng dụng. Nút chỉ có trong những phiên mở bằng Start-Pixel.cmd. Mở Codex bình thường từ Start không tự thêm nút. Thay đổi phiên bản Codex có thể cần cập nhật bộ chèn.
Video được thêm từ tệp trên máy; không nhập đường dẫn YouTube hoặc phát trực tiếp từ website. Một số codec trong MP4/MOV không được hỗ trợ; thử MP4 H.264 hoặc WebM.
Đóng cổng CDP: Ctrl+Q để thoát hoàn toàn rồi mở Codex bình thường. Cổng CDP cho phép tiến trình cục bộ tiếp cận renderer; đừng chia sẻ/forward cổng.

Đã kiểm tra ngày 7/11/2026
- Gói OpenAI.Codex 26.1103.4239.0 trên Windows.
- Nút trên thanh công cụ nhận chuột và mở được bảng chọn.
- Tắt/bật nền vẫn giữ nút, thanh độ sáng thay đổi, đặt lại hoạt động.
- 9 ảnh xem trước và engine vẽ cảnh chạy.
- Hộp chọn video mở, WebM mẫu 480x270 lưu được và phát lặp, tắt tiếng, có chuyển động.
- Thoát và mở lại qua Start-Pixel.ps1: nút và video đã lưu được khôi phục.
- Đã chuyển lại nền Koi sau thử nghiệm; video mẫu còn trong thư viện để bạn thử.

Nguồn engine: aqua2409z, pixel-chat-themes-main.zip do người dùng cung cấp, giấy phép MIT (LICENSE.txt).
Mã giao diện và bộ chèn: bản tùy biến cục bộ trong adapter-v2.js, pixel-runtime.js, inject.mjs.
Tham khảo cách khởi chạy:
https://github.com/JonathandNidhog/dsh-plugin-wallpaper-engine-codex
https://github.com/codecnmc/codex-theme-inject
